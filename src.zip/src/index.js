import BpmnModeler from 'bpmn-js/lib/Modeler';
// Import your CSS files
import 'bpmn-js/dist/assets/diagram-js.css';
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn.css';
import 'bpmn-js/dist/assets/bpmn-js.css';
import './styles.css';

// Add event listeners
document.getElementById('newDiagram').addEventListener('click', newDiagram);
document.getElementById('loadDiagram').addEventListener('click', loadDiagram);
document.getElementById('saveDiagram').addEventListener('click', saveDiagram);
document.getElementById('exportDiagram').addEventListener('click', exportDiagram);
document.getElementById('formatCustomProperties').addEventListener('click', formatCustomProperties);
document.getElementById('loadLucidCSV').addEventListener('click', loadLucidCSV);
document.getElementById('saveProperties').addEventListener('click', saveProperties);
document.getElementById('resetProperties').addEventListener('click', resetProperties);

// Initialize the modeler
const modeler = new BpmnModeler({
    container: '#canvas',
    height: '100%',
    width: '100%'
});

// Create empty diagram
modeler.createDiagram();
  
  let selectedElement = null;
  let originalProperties = {};
  
  // Load default BPMN diagram
  const defaultDiagram = `<?xml version="1.0" encoding="UTF-8"?>
  <bpmn:definitions 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
    xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" 
    xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" 
    xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" 
    xmlns:custom="http://custom/ns"
    id="Definitions_1" 
    targetNamespace="http://bpmn.io/schema/bpmn">
    <bpmn:process id="Process_1" isExecutable="false">
      <bpmn:startEvent id="StartEvent_1" />
    </bpmn:process>
    <bpmndi:BPMNDiagram id="BPMNDiagram_1">
      <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1">
        <bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="StartEvent_1">
          <dc:Bounds x="179" y="79" width="36" height="36" />
        </bpmndi:BPMNShape>
      </bpmndi:BPMNPlane>
    </bpmndi:BPMNDiagram>
  </bpmn:definitions>`;
  
  // Import the diagram
  modeler.importXML(defaultDiagram)
    .then(() => {
      const canvas = modeler.get('canvas');
      canvas.zoom('fit-viewport');
      console.log('Success!');
    })
    .catch(err => {
      console.error('Error loading diagram', err);
    });
  
  // Handle element selection
  modeler.on('element.click', function(event) {
    selectedElement = event.element;
    updateProperties(selectedElement);
    storeOriginalProperties();
  });
  
  function storeOriginalProperties() {
    if (!selectedElement) return;
    
    const customProps = {};
    Object.entries(selectedElement.businessObject.$attrs || {}).forEach(([key, value]) => {
      if (key.startsWith('custom:')) {
        const propName = key.replace('custom:', '');
        customProps[propName] = value;
      }
    });
  
    originalProperties = {
      name: selectedElement.businessObject.name || '',
      description: selectedElement.businessObject.documentation?.[0]?.text || '',
      customProperties: JSON.stringify(customProps, null, 2)
    };
  }
  
  function updateProperties(element) {
    if (!element) return;
  
    const elementId = document.getElementById('elementId');
    const elementType = document.getElementById('elementType');
    const elementName = document.getElementById('elementName');
    const elementDescription = document.getElementById('elementDescription');
    const customProperties = document.getElementById('customProperties');
  
    if (elementId) elementId.value = element.id || '';
    if (elementType) elementType.value = element.type || '';
    if (elementName) elementName.value = element.businessObject.name || '';
    if (elementDescription) {
      elementDescription.value = element.businessObject.documentation?.[0]?.text || '';
    }
  
    // Extract custom properties
    if (customProperties) {
      const customProps = {};
      Object.entries(element.businessObject.$attrs || {}).forEach(([key, value]) => {
        if (key.startsWith('custom:')) {
          const propName = key.replace('custom:', '');
          customProps[propName] = value;
        }
      });
      customProperties.value = JSON.stringify(customProps, null, 2);
    }
  }
  
  function validateProperties() {
    const name = document.getElementById('elementName').value;
    const customPropsField = document.getElementById('customProperties');
  
    if (!name.trim()) {
      showMessage('Name is required', 'error');
      return false;
    }
  
    try {
      JSON.parse(customPropsField.value);
      customPropsField.style.border = ""; // Reset border if valid
    } catch (e) {
      showMessage('Invalid JSON in custom properties: ' + e.message, 'error');
      customPropsField.style.border = "2px solid red"; // Highlight invalid field
      return false;
    }
  
    return true;
  }
  
  function saveProperties() {
    if (!selectedElement || !validateProperties()) return;
  
    const modeling = modeler.get('modeling');
    const moddle = modeler.get('moddle');
    
    try {
      // Update name and documentation
      const name = document.getElementById('elementName').value;
      const description = document.getElementById('elementDescription').value;
      
      // Create documentation element if there's a description
      let documentation = undefined;
      if (description) {
        documentation = moddle.create('bpmn:Documentation', {
          text: description
        });
      }
  
      // Update basic properties
      modeling.updateProperties(selectedElement, {
        name: name,
        documentation: documentation ? [documentation] : undefined
      });
  
      // Handle custom properties
      try {
        const customProps = JSON.parse(document.getElementById('customProperties').value);
        
        // Convert custom properties to BPMN-compatible format
        const customAttributes = {};
        Object.entries(customProps).forEach(([key, value]) => {
          customAttributes[`custom:${key}`] = value.toString();
        });
  
        // Update custom properties
        modeling.updateProperties(selectedElement, customAttributes);
      } catch (e) {
        console.warn('Error parsing custom properties:', e);
      }
  
      showMessage('Properties saved successfully', 'success');
      storeOriginalProperties();
    } catch (error) {
      console.error('Error saving properties:', error);
      showMessage('Error saving properties: ' + error.message, 'error');
    }
  }
  
  function resetProperties() {
    if (!selectedElement) return;
    
    document.getElementById('elementName').value = originalProperties.name;
    document.getElementById('elementDescription').value = originalProperties.description;
    document.getElementById('customProperties').value = originalProperties.customProperties;
  }
  
  function exportDiagram() {
    modeler.saveXML({ format: true }, function(err, xml) {
      if (err) {
        showMessage('Error exporting diagram', 'error');
        return console.error('Error saving diagram', err);
      }
      
      download(xml, 'diagram.bpmn', 'application/xml');
      showMessage('Diagram exported successfully', 'success');
    });
  }

  
  function download(content, fileName, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  // Function to create a new empty diagram
async function newDiagram() {
  try {
    const emptyDiagram = '<?xml version="1.0" encoding="UTF-8"?>' +
      '<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" ' +
      'xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" ' +
      'xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" ' +
      'id="Definitions_1" ' +
      'targetNamespace="http://bpmn.io/schema/bpmn">' +
      '<bpmn:process id="Process_1" isExecutable="false">' +
      '<bpmn:startEvent id="StartEvent_1"/>' +
      '</bpmn:process>' +
      '<bpmndi:BPMNDiagram id="BPMNDiagram_1">' +
      '<bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1">' +
      '<bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="StartEvent_1">' +
      '<dc:Bounds x="152" y="102" width="36" height="36"/>' +
      '</bpmndi:BPMNShape>' +
      '</bpmndi:BPMNPlane>' +
      '</bpmndi:BPMNDiagram>' +
      '</bpmn:definitions>';

    await modeler.importXML(emptyDiagram);
    showMessage('New diagram created successfully', 'success');
  } catch (err) {
    showMessage('Error creating new diagram', 'error');
    console.error('Error creating new diagram', err);
  }
}

// Function to trigger file input for loading a diagram
function loadDiagram() {
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = '.bpmn';
  fileInput.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      const xml = e.target.result;
      try {
        await modeler.importXML(xml);
        showMessage('Diagram loaded successfully', 'success');
      } catch (err) {
        showMessage('Error loading diagram', 'error');
        console.error('Error loading diagram', err);
      }
    };
    reader.readAsText(file);
  };
  fileInput.click();
}

// Function to save the diagram
async function saveDiagram() {
  try {
    const { xml } = await modeler.saveXML({ format: true });
    const blob = new Blob([xml], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'diagram.bpmn';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showMessage('Diagram saved successfully', 'success');
  } catch (err) {
    showMessage('Error saving diagram', 'error');
    console.error('Error saving diagram', err);
  }
}

// Helper function to show messages
function showMessage(message, type) {
  const messageArea = document.getElementById('messageArea');
  messageArea.textContent = message;
  messageArea.className = type;
  messageArea.style.display = 'block';
  setTimeout(() => {
    messageArea.style.display = 'none';
  }, 3000);
}

function formatCustomProperties() {
  const customPropsField = document.getElementById('customProperties');
  try {
    const parsedJson = JSON.parse(customPropsField.value);
    customPropsField.value = JSON.stringify(parsedJson, null, 2); // Pretty-print JSON
  } catch (e) {
    showMessage('Invalid JSON, cannot format', 'error');
  }
}

function autoSaveDiagram() {
  modeler.saveXML({ format: true }, function(err, xml) {
    if (!err) {
      localStorage.setItem('bpmnDiagram', xml);
    }
  });
}

function parseLucidCSV(csvContent) {
  // Split CSV into lines and remove empty lines
  const lines = csvContent.split('\n').filter(line => line.trim());
  
  // Parse header and rows
  const headers = lines[0].split(',').map(h => h.trim());
  const rows = lines.slice(1).map(line => {
    const values = line.split(',').map(v => v.trim());
    return headers.reduce((obj, header, i) => {
      obj[header] = values[i] || '';
      return obj;
    }, {});
  });
  
  return rows;
}

function parseCustomProperties(comments) {
  if (!comments) return {};
  
  try {
    // Extract key-value pairs from the comments string
    const pairs = comments.match(/\[(.*?)\]/g);
    if (!pairs) return {};
    
    const properties = {};
    pairs.forEach(pair => {
      // Remove brackets and split by semicolon
      const parts = pair.slice(1, -1).split(';').map(p => p.trim());
      
      parts.forEach(part => {
        const [key, value] = part.split(':').map(s => s.trim());
        if (key && value) {
          // Handle nested JSON for Input
          if (key === 'Input' && value.includes('=')) {
            const inputObj = {};
            const [inputKey, inputValue] = value.split('=').map(s => s.trim().replace(/"/g, ''));
            inputObj[inputKey] = inputValue;
            properties[key] = inputObj;
          } else {
            properties[key] = value.replace(/"/g, '');
          }
        }
      });
    });
    
    return properties;
  } catch (error) {
    console.error('Error parsing custom properties:', error);
    return {};
  }
}

function createGraph(shapes, connections) {
  const graph = new Map();
  
  // Initialize graph with all shapes
  shapes.forEach(shape => {
    graph.set(shape.id, { shape, next: [], prev: [], level: -1 });
  });
  
  // Add connections
  connections.forEach(conn => {
    const sourceId = `Shape_${conn['Line Source']}`;
    const targetId = `Shape_${conn['Line Destination']}`;
    
    if (graph.has(sourceId) && graph.has(targetId)) {
      graph.get(sourceId).next.push(targetId);
      graph.get(targetId).prev.push(sourceId);
    }
  });
  
  return graph;
}

function assignLevels(graph) {
  // Find start node (node with no incoming connections)
  const start = Array.from(graph.entries()).find(([_, data]) => data.prev.length === 0);
  if (!start) return;
  
  // Assign levels using BFS
  const queue = [{id: start[0], level: 0}];
  const visited = new Set();
  
  while (queue.length > 0) {
    const {id, level} = queue.shift();
    if (visited.has(id)) continue;
    
    visited.add(id);
    const node = graph.get(id);
    node.level = level;
    
    // Add all unvisited neighbors to queue
    node.next.forEach(nextId => {
      if (!visited.has(nextId)) {
        queue.push({id: nextId, level: level + 1});
      }
    });
  }
  
  // Handle any disconnected nodes
  graph.forEach((data, id) => {
    if (data.level === -1) {
      data.level = 0;
    }
  });
}

function calculateAutoLayout(shapes, connections) {
  const LEVEL_SPACING = 200;
  const NODE_SPACING = 150;
  
  // Create and analyze graph
  const graph = createGraph(shapes, connections);
  assignLevels(graph);
  
  // Group nodes by level
  const levels = new Map();
  graph.forEach((data, id) => {
    if (!levels.has(data.level)) {
      levels.set(data.level, []);
    }
    levels.get(data.level).push({id, shape: data.shape});
  });
  
  // Position nodes
  levels.forEach((nodes, level) => {
    const levelWidth = nodes.length * NODE_SPACING;
    const startX = (levelWidth / 2) * -1 + NODE_SPACING/2;
    
    nodes.forEach((node, index) => {
      const shape = node.shape;
      shape.x = startX + (index * NODE_SPACING);
      shape.y = level * LEVEL_SPACING;
    });
  });
  
  return shapes;
}

function convertToBPMN(csvContent) {
  const rows = parseLucidCSV(csvContent);
  const shapes = [];
  const connections = [];
  
  // First pass: Create shapes
  rows.forEach((row, index) => {
    if (row.Name === 'Document' || row.Name === 'Page') return;
    
    if (row.Name === 'Line') {
      connections.push(row);
      return;
    }
    
    const customProps = parseCustomProperties(row.comments);
    
    let shape = {
      id: `Shape_${row.Id}`,
      type: 'unknown',
      name: row['Text Area 1'] || '',
      x: 0,
      y: 0,
      width: 100,
      height: 80,
      customProperties: customProps
    };
    
    switch (row.Name) {
      case 'Terminator':
        if (shapes.length === 0) {
          shape.type = 'bpmn:startEvent';
          shape.width = 36;
          shape.height = 36;
        } else {
          shape.type = 'bpmn:endEvent';
          shape.width = 36;
          shape.height = 36;
        }
        break;
      case 'Process':
        shape.type = 'bpmn:task';
        break;
      case 'Decision':
        shape.type = 'bpmn:exclusiveGateway';
        shape.width = 50;
        shape.height = 50;
        break;
      case 'Note':
        shape.type = 'bpmn:textAnnotation';
        shape.width = 120;
        shape.height = 30;
        break;
    }
    
    shapes.push(shape);
  });
  
  // Auto-layout the shapes
  const layoutedShapes = calculateAutoLayout(shapes, connections);
  
  // Generate BPMN XML
  const bpmnXML = `<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions 
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
  xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" 
  xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" 
  xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" 
  xmlns:di="http://www.omg.org/spec/DD/20100524/DI"
  xmlns:custom="http://custom/ns"
  id="Definitions_1" 
  targetNamespace="http://bpmn.io/schema/bpmn">
  <bpmn:process id="Process_1" isExecutable="false">
    ${layoutedShapes.map(shape => {
      const customProps = Object.entries(shape.customProperties)
        .map(([key, value]) => `custom:${key}="${typeof value === 'object' ? JSON.stringify(value) : value}"`)
        .join(' ');
      
      return `<${shape.type} id="${shape.id}" name="${shape.name}" ${customProps}/>`;
    }).join('\n    ')}
    
    ${connections.map(conn => {
      const sourceShape = shapes.find(s => s.id === `Shape_${conn['Line Source']}`);
      const targetShape = shapes.find(s => s.id === `Shape_${conn['Line Destination']}`);
      
      if (!sourceShape || !targetShape) return '';
      
      return `<bpmn:sequenceFlow id="Flow_${conn.Id}" 
        sourceRef="${sourceShape.id}" 
        targetRef="${targetShape.id}" 
        name="${conn['Text Area 1'] || ''}" />`;
    }).join('\n    ')}
  </bpmn:process>
  
  <bpmndi:BPMNDiagram id="BPMNDiagram_1">
    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1">
      ${layoutedShapes.map(shape => `
      <bpmndi:BPMNShape id="${shape.id}_di" bpmnElement="${shape.id}">
        <dc:Bounds x="${shape.x}" y="${shape.y}" width="${shape.width}" height="${shape.height}" />
      </bpmndi:BPMNShape>`).join('\n      ')}
      
      ${connections.map(conn => {
        const sourceShape = shapes.find(s => s.id === `Shape_${conn['Line Source']}`);
        const targetShape = shapes.find(s => s.id === `Shape_${conn['Line Destination']}`);
        
        if (!sourceShape || !targetShape) return '';
        
        return `<bpmndi:BPMNEdge id="Flow_${conn.Id}_di" bpmnElement="Flow_${conn.Id}">
          <di:waypoint x="${sourceShape.x + sourceShape.width/2}" y="${sourceShape.y + sourceShape.height/2}" />
          <di:waypoint x="${targetShape.x + targetShape.width/2}" y="${targetShape.y + targetShape.height/2}" />
        </bpmndi:BPMNEdge>`;
      }).join('\n      ')}
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</bpmn:definitions>`;

  return bpmnXML;
}

// Function to integrate with your existing code
async function importLucidCSV(csvContent) {
  try {
    const bpmnXML = convertToBPMN(csvContent);
    await modeler.importXML(bpmnXML);
    const canvas = modeler.get('canvas');
    canvas.zoom('fit-viewport');
    showMessage('Lucid CSV imported successfully', 'success');
  } catch (error) {
    console.error('Error importing Lucid CSV:', error);
    showMessage('Error importing Lucid CSV', 'error');
  }
}

function loadLucidCSV() {
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = '.csv';
  fileInput.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      const csv = e.target.result;
      await importLucidCSV(csv);
    };
    reader.readAsText(file);
  };
  fileInput.click();
}

// Auto-save every 10 seconds
setInterval(autoSaveDiagram, 10000);

const savedDiagram = localStorage.getItem('bpmnDiagram');
if (savedDiagram) {
  modeler.importXML(savedDiagram).then(() => {
    console.log('Loaded saved diagram.');
  }).catch(err => {
    console.error('Error loading saved diagram', err);
  });
} else {
  modeler.importXML(defaultDiagram);
}

document.addEventListener('dragover', (event) => {
  event.preventDefault();
});

document.addEventListener('drop', async (event) => {
  event.preventDefault();
  const file = event.dataTransfer.files[0];

  if (file && file.name.endsWith('.bpmn')) {
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        await modeler.importXML(e.target.result);
        showMessage('Diagram loaded successfully', 'success');
      } catch (err) {
        showMessage('Error loading diagram', 'error');
        console.error('Error loading diagram', err);
      }
    };
    reader.readAsText(file);
  }
});